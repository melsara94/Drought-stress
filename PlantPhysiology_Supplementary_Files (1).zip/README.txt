Supplementary files - Letter to Plant Physiology (Sarabandi, Kumar, Chen, Wang)
Supplementary_Data.docx / .pdf   Supplementary Methods + Tables S1-S6
tables/                           every table as CSV (+ Fig1A_papers_per_year.csv, TableS3c_soft_weights.csv)
pubmed_raw.csv                    the 2,000 retrieved PubMed records
code/                             run in order: step1, step2, step3, step6, step7, step8, step10 (step11 = query re-run check, needs internet)
Edit the paths at the top of each script (default D:\Melina\Melina\mining_data).
Run step6 after step1 (it reads model_artifacts_k5). step10 builds tables/ from the outputs of the other steps.
Independent re-run (gensim 4.4.0) reproduced topic sizes 338/424/285/542/394 and c_v 0.4523.
