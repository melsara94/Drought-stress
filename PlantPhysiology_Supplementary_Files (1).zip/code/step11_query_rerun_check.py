"""
STEP 11 -- Re-run of the PubMed query without the 2,000-record cap (Letter, Table S3).

Answers: does the genome-wide/gene-family trend change when the records omitted by the
2,000-record cap are added?  Needs internet (NCBI Entrez).  In Spyder: set EMAIL below, then press F5.
From a terminal: python step11_query_rerun_check.py your.email@example.com
(Entrez asks for a contact e-mail; it is sent only to NCBI.)

Outputs in model_artifacts_k5/supplementary_tables:
    pubmed_rerun_all.csv   every record returned by the re-run (keep this; cite its date)
    TableS3_rerun_row.csv  numbers for the Table S3 row
"""
import os, re, sys, time, datetime
import numpy as np, pandas as pd

QUERY = "drought tolerance genes crops"
DATA = r"D:\Melina\Melina\mining_data"
ORIG = os.path.join(DATA, "pubmed_raw.csv")
OUT = os.path.join(DATA, "model_artifacts_k5", "supplementary_tables"); os.makedirs(OUT, exist_ok=True)
EMAIL = "your.email@example.com"   # <-- EDIT: any real address (sent only to NCBI)
email = sys.argv[1] if len(sys.argv) > 1 and "@" in sys.argv[1] else EMAIL
src_csv = sys.argv[sys.argv.index("--from-csv") + 1] if "--from-csv" in sys.argv else None

if src_csv:                                    # offline test mode
    allr = pd.read_csv(src_csv); count = len(allr)
else:
    from Bio import Entrez, Medline
    Entrez.email = email
    h = Entrez.esearch(db="pubmed", term=QUERY, usehistory="y", retmax=0)
    r = Entrez.read(h); count = int(r["Count"]); web, key = r["WebEnv"], r["QueryKey"]
    print(f"PubMed reports {count} records for: {QUERY}  ({datetime.date.today()})")
    rows = []
    for start in range(0, count, 200):
        for attempt in range(5):
            try:
                h = Entrez.efetch(db="pubmed", rettype="medline", retmode="text", retstart=start, retmax=200, webenv=web, query_key=key)
                for rec in Medline.parse(h):
                    rows.append(dict(pmid=rec.get("PMID"), title=rec.get("TI"), abstract=rec.get("AB"),
                                     year=(rec.get("DP", "") or "")[:4], journal=rec.get("TA")))
                break
            except Exception as e:
                print("retry", start, e); time.sleep(3)
        time.sleep(0.4)
    allr = pd.DataFrame(rows)
allr.to_csv(os.path.join(OUT, "pubmed_rerun_all.csv"), index=False)

# ---- same eligibility rules as step1 ----
STOPWORDS = set("""
a about above after again against all am an and any are as at be because
been before being below between both but by could did do does doing down
during each few for from further had has have having he her here hers
herself him himself his how i if in into is it its itself just me more
most my myself no nor not now of off on once only or other our ours
ourselves out over own same she should so some such than that the their
theirs them themselves then there these they this those through to too
under until up very was we were what when where which while who whom why
will with you your yours yourself yourselves plant plants expression
identified revealed role response responses analysis study studies
results showed shown using used may also however between within sub sup
""".split())

def clean_text(text):                                          # identical to step1
    text = text.lower()
    text = re.sub(r"</?(sub|sup|i|b|italic|bold)>", " ", text)
    text = re.sub(r"[^a-z\s-]", " ", text)
    return [t for t in text.split() if t not in STOPWORDS and len(t) > 2]
def eligible(df):
    df = df.dropna(subset=["abstract"]); df = df[df["abstract"].str.len() > 20].copy()
    df["ft"] = df["title"].fillna("") + " " + df["abstract"]
    df = df[[len(clean_text(t)) > 3 for t in df["ft"]]]
    df["year"] = pd.to_numeric(df["year"], errors="coerce"); df = df[df["year"].notna()].copy(); df["year"] = df["year"].astype(int)
    vc = df["year"].value_counts(); df = df[df["year"] >= min(vc[vc >= 5].index)]
    return df.reset_index(drop=True)

pat = re.compile(r"genome-wide|gene famil|identification and (?:expression|characteri[sz]ation)", re.I)
def pct(df, lo, hi):
    m = df[(df.year >= lo) & (df.year <= hi)]
    if len(m) == 0: return 0, 0, float("nan")
    x = m["ft"].apply(lambda t: bool(pat.search(t)))
    return len(m), int(x.sum()), 100 * x.mean() if len(m) else np.nan

orig_ids = set(pd.read_csv(ORIG)["pmid"].astype(str))
full = eligible(allr); full["pmid"] = full["pmid"].astype(str)
sets = {"Original capped sample": full[full.pmid.isin(orig_ids)], "Full re-run (all eligible)": full, "Newly added records only": full[~full.pmid.isin(orig_ids)]}
rows = []
for name, d in sets.items():
    n1, x1, p1 = pct(d, 2006, 2012); n2, x2, p2 = pct(d, 2022, 2026)
    rows.append(dict(set=name, eligible_n=len(d), n_2006_12=n1, x_2006_12=x1, pct_2006_12=round(p1, 1), n_2022_26=n2, x_2022_26=x2, pct_2022_26=round(p2, 1)))
res = pd.DataFrame(rows); res.insert(0, "run_date", str(datetime.date.today())); res.insert(1, "pubmed_count", count)
res.to_csv(os.path.join(OUT, "TableS3_rerun_row.csv"), index=False)
print(res.to_string(index=False))
r = res.iloc[1]
print(f"\nSentence for Table S3: On {r.run_date} the query returned {count} records ({int(r.eligible_n)} eligible). "
      f"Genome-wide/gene-family terms: {r.pct_2006_12}% (2006-2012) vs {r.pct_2022_26}% (2022-2026) in the full re-run; "
      f"{res.iloc[0].pct_2006_12}% vs {res.iloc[0].pct_2022_26}% in the original capped sample.")
