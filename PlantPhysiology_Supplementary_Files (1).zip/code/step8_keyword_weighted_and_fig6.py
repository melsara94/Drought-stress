"""
STEP 8 -- Keyword-group trends with three tests (OLS, weighted, logistic)
and the redrawn Figure 6 (three-year periods). Independent of the topic model.

Reads corpus_with_topics.csv (step1). Writes in model_artifacts_k5:
    keyword_trends_weighted.csv   (Table 5)
    fig6_keyword_trends.png
"""
import os, re, sys
import numpy as np, pandas as pd, statsmodels.api as sm
from scipy import stats
import matplotlib.pyplot as plt

ARTIFACT_DIR = sys.argv[1] if len(sys.argv) > 1 else r"D:\Melina\Melina\mining_data\model_artifacts_k5"
df = pd.read_csv(os.path.join(ARTIFACT_DIR, "corpus_with_topics.csv"))
text = (df["title"].fillna("") + " " + df["abstract"].fillna("")).tolist()
y = df["year"].values

def ci(w): return re.compile(w, re.I)
def cs(a): return re.compile(rf"(?<![A-Z]){a}(?![A-Z])")
G = {"Any TF family": [ci("wrky"), ci("bzip"), ci("dreb"), ci("myb"), ci("bhlh"), ci("hsf"), cs("ERF"), cs("AP2"), cs("NAC"), ci(r"transcription factors?")],
     "AP2/ERF/DREB only": [ci("dreb"), cs("ERF"), cs("AP2")],
     "WRKY/NAC/MYB/bZIP": [ci("wrky"), cs("NAC"), ci("myb"), ci("bzip")],
     "Physiological markers": [ci("proline"), ci("catalase"), ci("peroxidase"), ci("superoxide dismutase"), ci("malondialdehyde"),
                               ci("relative water content"), ci("electrolyte leakage"), cs("SOD"), cs("POD"), cs("CAT"), cs("MDA")],
     "Genome-wide / gene-family": [ci("genome-wide"), ci("gene famil"), ci(r"identification and (expression|characteri[sz]ation)")],
     "CRISPR / genome editing": [ci("crispr"), ci("genome editing")]}

early, late = y <= 2012, y >= 2022
rows, flags = [], {}
for name, pats in G.items():
    f = np.array([any(p.search(t) for p in pats) for t in text]).astype(float)
    flags[name] = f
    s = pd.Series(f).groupby(y).agg(["mean", "size"])
    sl, _, _, p_ols, _ = stats.linregress(s.index.values, s["mean"].values)
    X = sm.add_constant(s.index.values - 2006.0)
    w = sm.WLS(s["mean"].values, X, weights=s["size"].values).fit()
    lg = sm.GLM(f, sm.add_constant(y - 2006.0), family=sm.families.Binomial()).fit()
    ci_ = np.exp(lg.conf_int()[1])
    rows.append(dict(group=name, papers=int(f.sum()), pct_2006_12=round(100 * f[early].mean(), 1),
                     pct_2022_26=round(100 * f[late].mean(), 1), ols_slope_pp=round(100 * sl, 2), ols_p=p_ols,
                     wls_slope_pp=round(100 * w.params[1], 2), wls_p=w.pvalues[1],
                     logistic_OR=round(float(np.exp(lg.params[1])), 3), OR_low=round(float(ci_[0]), 3),
                     OR_high=round(float(ci_[1]), 3), logistic_p=lg.pvalues[1]))
out = pd.DataFrame(rows)
for c in ["ols_p", "wls_p", "logistic_p"]:
    out[c + "_bonf"] = (out[c] * len(out)).clip(upper=1)
out.to_csv(os.path.join(ARTIFACT_DIR, "keyword_trends_weighted.csv"), index=False)
pd.set_option("display.width", 250); pd.set_option("display.max_columns", 30)
print(out.to_string(index=False, float_format=lambda v: f"{v:.5g}"))

# ---- Figure 6: three-year periods anchored at 2006 ----
bins = (y - 2006) // 3; nb = bins.max() + 1; n = np.bincount(bins)
labels = [f"{2006+3*b}\u2013{str(2006+3*b+2)[2:]}" for b in range(nb)]
style = {"Genome-wide / gene-family": ("#1f5fa8", "o", "-", 2.4), "CRISPR / genome editing": ("#c8611a", "s", "-", 2.4),
         "Physiological markers": ("#2a8a6b", "^", "--", 2.0), "Any TF family": ("#8a8a8a", "o", "-", 1.4),
         "WRKY/NAC/MYB/bZIP": ("#a9a9a9", "o", "-", 1.4), "AP2/ERF/DREB only": ("#6e6e6e", "o", ":", 1.6)}
fig, ax = plt.subplots(figsize=(8.6, 5.0)); last_y = {}
for name, f in flags.items():
    v = [100 * f[bins == b].mean() for b in range(nb)]; last_y[name] = v[-1]
    c, m, ls, lw = style[name]
    ax.plot(range(nb), v, color=c, marker=m, ls=ls, lw=lw, ms=5, zorder=3 if lw > 2 else 2)
prev = -99
for k in sorted(last_y, key=last_y.get):
    a = max(last_y[k], prev + 3.2); prev = a
    ax.text(nb - 1 + 0.12, a, k, fontsize=9, va="center", color=style[k][0] if style[k][3] > 2 else "#444")
ax.set_xticks(range(nb)); ax.set_xticklabels([f"{l}\n(n={c})" for l, c in zip(labels, n)], fontsize=8.5)
ax.set_xlim(-0.2, nb - 1 + 2.1); ax.set_ylim(0, None)
ax.set_ylabel("% of papers mentioning the term group")
ax.set_xlabel("Three-year period (last bin includes partial year 2026)")
for s_ in ("top", "right"): ax.spines[s_].set_visible(False)
ax.grid(axis="y", color="#e5e5e5", lw=0.8); ax.set_axisbelow(True)
fig.tight_layout(); fig.savefig(os.path.join(ARTIFACT_DIR, "fig6_keyword_trends.png"), dpi=220, facecolor="white")
print("Saved keyword_trends_weighted.csv and fig6_keyword_trends.png")
