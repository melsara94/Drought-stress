"""
STEP 3 of 3 -- Seed-stability check, K-Means validation and forecast, ALL
computed from the single canonical corpus saved by step1.
==================================================================

Nothing here re-cleans text or rebuilds the dictionary. It loads:
   corpus_with_topics.csv, dictionary.gensim, corpus.pkl, lda_model.gensim
so "Topic 6" / "Topic 7" mean exactly what they mean in step2.

The stability check does re-fit LDA under other random seeds (that is its
purpose), but on the SAME corpus and dictionary.

--------------------------------------------------------------------------
USAGE (after step1 and step2):
    python step3_validation_and_forecast.py

    Produces in D:\\Melina\\Melina\\mining_data\\model_artifacts:
       - stability_results.csv
       - kmeans_validation.csv
       - forecast_validation.csv
       - table4_forecast.csv
       - fig7_forecast.png
--------------------------------------------------------------------------
"""

import os
import pickle

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
import statsmodels.api as sm
from scipy import stats
from gensim import matutils
from gensim.corpora import Dictionary
from gensim.models import LdaModel, TfidfModel
from sklearn.cluster import KMeans
from sklearn.metrics import (adjusted_rand_score, normalized_mutual_info_score,
                             mean_absolute_error)

# =========================================================================
# CONFIG (must match step1 / step2)
# =========================================================================
DATA_DIR = r"D:\Melina\Melina\mining_data"
NUM_TOPICS = 5
ARTIFACT_DIR = os.path.join(DATA_DIR, f"model_artifacts_k{NUM_TOPICS}")
RISING_TOPIC_ID = 1      # k=5 (check against topic_top_words.csv)
DECLINING_TOPIC_ID = 4   # k=5 (check against topic_top_words.csv)
EXTRA_SEEDS = [1, 7, 21, 99, 123]   # five additional seeds (canonical seed is 42)
N_HOLDOUT_YEARS = 3
N_FORECAST_YEARS = 5


def load_artifacts():
    df = pd.read_csv(os.path.join(ARTIFACT_DIR, "corpus_with_topics.csv"))
    dictionary = Dictionary.load(os.path.join(ARTIFACT_DIR, "dictionary.gensim"))
    with open(os.path.join(ARTIFACT_DIR, "corpus.pkl"), "rb") as f:
        corpus = pickle.load(f)
    lda = LdaModel.load(os.path.join(ARTIFACT_DIR, "lda_model.gensim"))
    assert len(df) == len(corpus), "corpus and dataframe lengths differ -- rerun step1"
    return df, dictionary, corpus, lda


def jaccard(a, b):
    return len(a & b) / len(a | b) if a and b else 0.0


def topic_share_trend(years_series, mask):
    """Annual share of documents where mask is True, then OLS trend."""
    share = pd.Series(mask.astype(float).values).groupby(years_series.values).mean()
    slope, _, r, p, _ = stats.linregress(share.index.values, share.values)
    return slope, r ** 2, p


# =========================================================================
# 1. Multi-seed stability
# =========================================================================
def stability(df, dictionary, corpus, lda_canon):
    rows = []
    for label, topic_id in [("rising", RISING_TOPIC_ID), ("declining", DECLINING_TOPIC_ID)]:
        target_words = {w for w, _ in lda_canon.show_topic(topic_id, topn=10)}
        for seed in EXTRA_SEEDS:
            print(f"Seed {seed}: fitting LDA for {label} topic matching...")
            model = LdaModel(corpus=corpus, id2word=dictionary, num_topics=NUM_TOPICS,
                             random_state=seed, passes=10, alpha="auto")
            best_t, best_j = None, -1
            for t in range(NUM_TOPICS):
                j = jaccard({w for w, _ in model.show_topic(t, topn=10)}, target_words)
                if j > best_j:
                    best_t, best_j = t, j
            dom = np.array([max(model.get_document_topics(b), key=lambda x: x[1])[0]
                            for b in corpus])
            slope, r2, p = topic_share_trend(df["year"], pd.Series(dom == best_t))
            rows.append({"topic_type": label, "seed": seed, "matched_topic": best_t,
                         "jaccard": round(best_j, 2), "slope_per_year": round(slope, 5),
                         "r_squared": round(r2, 3), "p_value": round(p, 5),
                         "significant_0.05": p < 0.05,
                         "same_direction_as_canonical": (slope > 0) == (label == "rising")})
    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(ARTIFACT_DIR, "stability_results.csv"), index=False)
    print("\n", out.to_string(index=False))
    for label in ("rising", "declining"):
        sub = out[out["topic_type"] == label]
        ok = (sub["significant_0.05"] & sub["same_direction_as_canonical"]).sum()
        print(f"\n{label}: significant, same direction in {ok} of {len(sub)} extra seeds")


# =========================================================================
# 2. TF-IDF + K-Means independent validation
# =========================================================================
def kmeans_validation(df, dictionary, corpus):
    tfidf = TfidfModel(corpus)
    X = matutils.corpus2csc(tfidf[corpus], num_terms=len(dictionary)).T.tocsr()
    km = KMeans(n_clusters=NUM_TOPICS, n_init=10, random_state=42).fit(X)
    clusters = km.labels_
    lda_topics = df["dominant_topic"].values

    ari = adjusted_rand_score(lda_topics, clusters)
    nmi = normalized_mutual_info_score(lda_topics, clusters)
    print(f"\nLDA vs K-Means: ARI={ari:.3f}  NMI={nmi:.3f}")

    rows = [{"metric": "ARI", "value": round(ari, 3)}, {"metric": "NMI", "value": round(nmi, 3)}]
    for label, t in [("rising", RISING_TOPIC_ID), ("declining", DECLINING_TOPIC_ID)]:
        in_topic = lda_topics == t
        overlaps = [(in_topic & (clusters == c)).sum() for c in range(NUM_TOPICS)]
        c = int(np.argmax(overlaps))
        in_cluster = clusters == c
        slope, r2, p = topic_share_trend(df["year"], pd.Series(in_cluster))
        rows.append({
            "metric": f"{label}: LDA topic {t} -> cluster {c}",
            "value": (f"topic docs in cluster={overlaps[c] / in_topic.sum():.1%}; "
                      f"cluster docs in topic={overlaps[c] / in_cluster.sum():.1%}; "
                      f"slope={slope:.5f}; R2={r2:.3f}; p={p:.5f}")})
        print(rows[-1]["metric"], "->", rows[-1]["value"])
    pd.DataFrame(rows).to_csv(os.path.join(ARTIFACT_DIR, "kmeans_validation.csv"), index=False)


# =========================================================================
# 3. Forecast with holdout validation (years centred for numerical stability)
# =========================================================================
def forecast(df):
    share = (df["dominant_topic"] == RISING_TOPIC_ID).groupby(df["year"]).mean()
    years = share.index.values.astype(float)
    values = share.values
    x0 = years.min()
    xc = years - x0

    tr_x, te_x = xc[:-N_HOLDOUT_YEARS], xc[-N_HOLDOUT_YEARS:]
    tr_y, te_y = values[:-N_HOLDOUT_YEARS], values[-N_HOLDOUT_YEARS:]
    val_rows = []
    for deg, name in [(1, "Linear"), (2, "Quadratic")]:
        m = sm.OLS(tr_y, np.vander(tr_x, deg + 1, increasing=True)).fit()
        mae = mean_absolute_error(te_y, m.predict(np.vander(te_x, deg + 1, increasing=True)))
        val_rows.append({"model": name, "holdout_MAE": round(mae, 5)})
    val = pd.DataFrame(val_rows).sort_values("holdout_MAE")
    val.to_csv(os.path.join(ARTIFACT_DIR, "forecast_validation.csv"), index=False)
    print("\nHoldout validation:\n", val.to_string(index=False))

    best_deg = 1 if val.iloc[0]["model"] == "Linear" else 2
    model = sm.OLS(values, np.vander(xc, best_deg + 1, increasing=True)).fit()
    fut_years = np.arange(years.max() + 1, years.max() + 1 + N_FORECAST_YEARS)
    fut = model.get_prediction(np.vander(fut_years - x0, best_deg + 1, increasing=True)
                               ).summary_frame(alpha=0.05)
    table4 = pd.DataFrame({
        "year": fut_years.astype(int),
        "predicted_share": fut["mean"].values.clip(0, 1),
        "lower_95": fut["obs_ci_lower"].values.clip(0, 1),
        "upper_95": fut["obs_ci_upper"].values.clip(0, 1)}).round(3)
    table4.to_csv(os.path.join(ARTIFACT_DIR, "table4_forecast.csv"), index=False)
    print(f"\nBest model: {val.iloc[0]['model']}\n", table4.to_string(index=False))

    plt.figure(figsize=(10, 6))
    plt.plot(years, values, "o-", color="#2a6f4f", label="Observed")
    plt.plot(table4["year"], table4["predicted_share"], "o--", color="#b0652f", label="Forecast")
    plt.fill_between(table4["year"], table4["lower_95"], table4["upper_95"],
                     color="#b0652f", alpha=0.2, label="95% prediction interval")
    plt.xticks(range(int(years.min()), int(table4["year"].max()) + 1, 2))
    plt.xlabel("Year (2026 is a partial year)")
    plt.ylabel("Share of publications")
    plt.title(f"Forecast: share of publications in Topic {RISING_TOPIC_ID}")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(ARTIFACT_DIR, "fig7_forecast.png"), dpi=150)
    plt.close()


def main():
    df, dictionary, corpus, lda = load_artifacts()
    print(f"Loaded canonical corpus: {len(df)} documents")
    kmeans_validation(df, dictionary, corpus)
    forecast(df)
    stability(df, dictionary, corpus, lda)   # slowest part (10 LDA fits), run last
    print("\nDone. All outputs saved in", ARTIFACT_DIR)


if __name__ == "__main__":
    main()
