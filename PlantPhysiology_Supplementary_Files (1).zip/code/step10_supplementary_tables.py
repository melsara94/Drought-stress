"""
STEP 10 -- Supplementary Tables S1-S6 for the Letter (Plant Physiology).

Assembles every number cited in the Letter's figure legends and text from the
saved k=5 model and the outputs of steps 1-9. Nothing here is typed by hand
except the interpretive topic labels in TOPIC_LABELS.

Run order:  step1 -> step2 -> step3 -> step6 -> step7 -> step8 -> step10
Reads  (model_artifacts_k5):  corpus_with_topics.csv, lda_model.gensim, corpus.pkl,
        topic_top_words.csv, table3_gene_family_frequency.csv, pct_papers_per_topic.csv,
        stability_results.csv, kmeans_validation.csv, forecast_table.csv (step3),
        k_sensitivity.csv (step6)
Writes  (model_artifacts_k5/supplementary_tables):  TableS1 ... TableS6 as CSV
USAGE:  python step10_supplementary_tables.py [artifact_dir]
"""
import os, re, sys, pickle
import numpy as np, pandas as pd, statsmodels.api as sm
from scipy import stats
from gensim.models import LdaModel

AD = sys.argv[1] if len(sys.argv) > 1 else r"D:\Melina\Melina\mining_data\model_artifacts_k5"
OUT = os.path.join(AD, "supplementary_tables"); os.makedirs(OUT, exist_ok=True)
RISING, DECLINING = 1, 4
# Interpretive labels (the Letter states that topic labels are interpretive)
TOPIC_LABELS = {0: "ABA signalling / overexpression in model and crop species",
                1: "Gene-family characterization",
                2: "Trait-genotype association in field crops",
                3: "Transgenic physiological stress responses (salt, growth)",
                4: "Breeding and reviews"}

df = pd.read_csv(os.path.join(AD, "corpus_with_topics.csv"))
y = df["year"].values.astype(int); top = df["dominant_topic"].values
text = (df["title"].fillna("") + " " + df["abstract"].fillna("")).tolist()
T = np.arange(5)

def fp(v):
    return '<0.0001' if v < 1e-4 else (f'{v:.4f}' if v < 0.01 else f'{v:.3f}')

def trend_row(f, yrs, base):
    """OLS (annual shares), WLS (weights = papers/year), logistic (paper level)."""
    s = pd.Series(f).groupby(yrs).agg(["mean", "size"])
    sl, _, r, p_ols, _ = stats.linregress(s.index.values, s["mean"].values)
    w = sm.WLS(s["mean"].values, sm.add_constant(s.index.values - float(base)), weights=s["size"].values).fit()
    lg = sm.GLM(f, sm.add_constant(yrs - float(base)), family=sm.families.Binomial()).fit()
    ci = np.exp(lg.conf_int()[1])
    return dict(ols_slope_pp_per_yr=100 * sl, ols_R2=r ** 2, ols_p=p_ols,
                wls_slope_pp_per_yr=100 * w.params[1], wls_p=w.pvalues[1],
                logistic_OR=float(np.exp(lg.params[1])), OR_lo=float(ci[0]), OR_hi=float(ci[1]), logistic_p=lg.pvalues[1])

# ---------------- Table S1: topic definitions ---------------------------------
tw = pd.read_csv(os.path.join(AD, "topic_top_words.csv"))
s1 = pd.DataFrame({"topic": T, "interpretive_label": [TOPIC_LABELS[t] for t in T],
                   "n_papers": [int((top == t).sum()) for t in T],
                   "pct_of_corpus": [round(100 * (top == t).mean(), 1) for t in T],
                   "top_10_words": tw.sort_values("topic")["top_words"].values})
s1.to_csv(os.path.join(OUT, "TableS1_topic_definitions.csv"), index=False)

# ---------------- Table S2: topic trend tests ----------------------------------
rows = []
for t in T:
    f = (top == t).astype(float)
    full = trend_row(f, y, 2006)
    m = y >= 2012
    sub = trend_row(f[m], y[m], 2012)
    rows.append(dict(topic=t, n=int(f.sum()),
                     **{f"full_{k}": v for k, v in full.items()},
                     **{f"y2012_26_{k}": v for k, v in sub.items()}))
s2 = pd.DataFrame(rows)
for c in ["full_ols_p", "full_wls_p", "full_logistic_p", "y2012_26_ols_p", "y2012_26_wls_p", "y2012_26_logistic_p"]:
    s2[c + "_bonf"] = (s2[c] * len(T)).clip(upper=1)
# Benjamini-Hochberg on the full-period OLS P values
p = s2["full_ols_p"].values; o = np.argsort(p); r = np.empty(5); m_ = len(p)
bh = np.minimum.accumulate((p[o] * m_ / (np.arange(m_) + 1))[::-1])[::-1]; r[o] = np.minimum(bh, 1)
s2["full_ols_p_fdr_bh"] = r
s2.to_csv(os.path.join(OUT, "TableS2_topic_trend_tests.csv"), index=False)

# ---------------- Table S3: sensitivity checks ---------------------------------
s3 = []
# (a) additional seeds
st = os.path.join(AD, "stability_results.csv")
if os.path.exists(st):
    for _, r in pd.read_csv(st).iterrows():
        s3.append(dict(check="Additional random seed", detail=f"{r.topic_type} topic, seed {int(r.seed)} (matched topic {int(r.matched_topic)})",
                       metric=f"top-10-word Jaccard {r.jaccard:.2f}; slope {r.slope_per_year:+.5f}/yr; R2 {r.r_squared:.3f}; P {fp(r.p_value)}",
                       same_direction_as_canonical=bool(r.same_direction_as_canonical), significant_0_05=bool(r["significant_0.05"])))
# (b) alternative k
ks = os.path.join(AD, "k_sensitivity.csv")
if os.path.exists(ks):
    for _, r in pd.read_csv(ks).iterrows():
        s3.append(dict(check="Alternative number of topics", detail=f"k={int(r.k)}, {r.direction} topic {int(r.topic)} (n={int(r.n_docs)})",
                       metric=f"slope {r.slope_per_year:+.4f}/yr; R2 {r.r_squared:.3f}; Bonferroni P {fp(r.bonferroni_p)}; top words: {r.top_words.replace(chr(95), chr(32))}",
                       same_direction_as_canonical=True, significant_0_05=bool(r.bonferroni_p < 0.05)))
# (c) soft topic weights (mean posterior probability per year; no hard assignment)
lda = LdaModel.load(os.path.join(AD, "lda_model.gensim"))
with open(os.path.join(AD, "corpus.pkl"), "rb") as fh: corpus = pickle.load(fh)
W = np.zeros((len(corpus), 5))
for i, b in enumerate(corpus):
    for t, pr in lda.get_document_topics(b, minimum_probability=0.0): W[i, t] = pr
soft = []
for t in T:
    s = pd.Series(W[:, t]).groupby(y).mean()
    sl, _, r, p, _ = stats.linregress(s.index.values, s.values)
    soft.append(dict(topic=t, mean_weight_2006_12=W[y <= 2012, t].mean(), mean_weight_2022_26=W[y >= 2022, t].mean(),
                     ols_slope_per_yr=sl, ols_R2=r ** 2, ols_p=p, bonferroni_p=min(1, p * 5)))
soft = pd.DataFrame(soft); soft.to_csv(os.path.join(OUT, "TableS3c_soft_weights.csv"), index=False)
for _, r in soft.iterrows():
    s3.append(dict(check="Soft topic weights (mean posterior probability per year)", detail=f"topic {int(r.topic)}",
                   metric=f"mean weight {r.mean_weight_2006_12:.3f} -> {r.mean_weight_2022_26:.3f}; slope {r.ols_slope_per_yr:+.5f}/yr; R2 {r.ols_R2:.3f}; Bonferroni P {fp(r.bonferroni_p)}",
                   same_direction_as_canonical=bool((r.ols_slope_per_yr > 0) == (r.topic == RISING)) if r.topic in (RISING, DECLINING) else np.nan,
                   significant_0_05=bool(r.bonferroni_p < 0.05)))
# (d) TF-IDF + K-Means
km = os.path.join(AD, "kmeans_validation.csv")
if os.path.exists(km):
    for _, r in pd.read_csv(km).iterrows():
        mm = re.search(r"p=([0-9.]+)$", str(r.value)); pv = float(mm.group(1)) if mm else np.nan
        v = str(r.value).replace("p=0.00000", "p<0.0001")
        s3.append(dict(check="TF-IDF + K-Means (k=5)", detail=str(r.metric), metric=v, same_direction_as_canonical=np.nan, significant_0_05=(pv < 0.05) if mm else np.nan))
pd.DataFrame(s3).to_csv(os.path.join(OUT, "TableS3_sensitivity.csv"), index=False)

# ---------------- Table S4: family mentions (Fig. 2A) --------------------------
t3 = pd.read_csv(os.path.join(AD, "table3_gene_family_frequency.csv"))
pc = pd.read_csv(os.path.join(AD, "pct_papers_per_topic.csv"), index_col=0)
s4 = t3.set_index("gene_family").join(pc.add_prefix("pct_papers_").rename(columns=lambda c: c.replace("topic_", "T")))
s4 = s4.reset_index().rename(columns={"index": "gene_family"})
s4.to_csv(os.path.join(OUT, "TableS4_family_mentions.csv"), index=False)

# ---------------- Table S5: keyword groups (Fig. 2B) ---------------------------
def ci_(w): return re.compile(w, re.I)
def cs_(a): return re.compile(rf"(?<![A-Z]){a}(?![A-Z])")
G = {"Any TF family": [ci_("wrky"), ci_("bzip"), ci_("dreb"), ci_("myb"), ci_("bhlh"), ci_("hsf"), cs_("ERF"), cs_("AP2"), cs_("NAC"), ci_(r"transcription factors?")],
     "AP2/ERF/DREB only": [ci_("dreb"), cs_("ERF"), cs_("AP2")],
     "WRKY/NAC/MYB/bZIP": [ci_("wrky"), cs_("NAC"), ci_("myb"), ci_("bzip")],
     "Physiological markers": [ci_("proline"), ci_("catalase"), ci_("peroxidase"), ci_("superoxide dismutase"), ci_("malondialdehyde"),
                               ci_("relative water content"), ci_("electrolyte leakage"), cs_("SOD"), cs_("POD"), cs_("CAT"), cs_("MDA")],
     "Genome-wide / gene-family": [ci_("genome-wide"), ci_("gene famil"), ci_(r"identification and (expression|characteri[sz]ation)")],
     "CRISPR / genome editing": [ci_("crispr"), ci_("genome editing")]}
bins = (y - 2006) // 3; nb = bins.max() + 1; nper = np.bincount(bins)
labels = [f"{2006+3*b}-{str(2006+3*b+2)[2:]}" for b in range(nb)]
early, late = y <= 2012, y >= 2022
rows = []
for name, pats in G.items():
    f = np.array([any(p.search(t) for p in pats) for t in text]).astype(float)
    r = dict(group=name, papers=int(f.sum()), pct_2006_12=100 * f[early].mean(), n_2006_12=int(early.sum()), x_2006_12=int(f[early].sum()),
             pct_2022_26=100 * f[late].mean(), n_2022_26=int(late.sum()), x_2022_26=int(f[late].sum()))
    for b in range(nb): r[f"pct_bin_{labels[b]}(n={nper[b]})"] = 100 * f[bins == b].mean()
    r.update(trend_row(f, y, 2006)); rows.append(r)
s5 = pd.DataFrame(rows)
for c in ["ols_p", "wls_p", "logistic_p"]: s5[c + "_bonf"] = (s5[c] * len(s5)).clip(upper=1)
s5.to_csv(os.path.join(OUT, "TableS5_keyword_trends.csv"), index=False)

# ---------------- Table S6: forecast (Fig. 2C) ---------------------------------
for src, dst in [("table4_forecast.csv", "TableS6_forecast.csv"), ("forecast_validation.csv", "TableS6b_holdout.csv")]:
    if os.path.exists(os.path.join(AD, src)):
        pd.read_csv(os.path.join(AD, src)).to_csv(os.path.join(OUT, dst), index=False)
pd.DataFrame({"year": sorted(set(y)), "papers": [int((y == v).sum()) for v in sorted(set(y))]}).to_csv(os.path.join(OUT, "Fig1A_papers_per_year.csv"), index=False)
print("Wrote tables to", OUT); print(os.listdir(OUT))
