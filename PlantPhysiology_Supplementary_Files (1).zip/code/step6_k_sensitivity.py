"""
STEP 6 -- Does the main finding depend on the number of topics (k)?
==================================================================

The coherence sweep (step5) peaked at k=5, not k=8, so the number of topics
must be justified. This script refits LDA for every k from 4 to 10 on the
SAME saved corpus/dictionary (seed 42, same settings as step1) and, for each k,
reports:
   * the topic with the strongest INCREASING yearly share trend,
   * the topic with the strongest DECREASING yearly share trend,
   * how many topics survive Bonferroni correction.
If a "gene-family" topic rises and a breeding/review topic falls at every
(or almost every) k, the finding does not depend on the k choice.

At k=8 it should reproduce the canonical model (rising = gene_family topic,
R2 about 0.79; declining = breeding topic, R2 about 0.36). If it does not,
tell me before going further.

USAGE: open in Spyder, press F5 (about 10-20 minutes; Spyder may show
"Not Responding" while it works). Needs step1 outputs only.
Produces: model_artifacts/k_sensitivity.csv
"""

import os
import pickle

import numpy as np
import pandas as pd
from scipy import stats
from gensim.corpora import Dictionary
from gensim.models import LdaModel

ARTIFACT_DIR = r"D:\Melina\Melina\mining_data\model_artifacts_k5"
RANDOM_SEED = 42


def main():
    df = pd.read_csv(os.path.join(ARTIFACT_DIR, "corpus_with_topics.csv"))
    dictionary = Dictionary.load(os.path.join(ARTIFACT_DIR, "dictionary.gensim"))
    with open(os.path.join(ARTIFACT_DIR, "corpus.pkl"), "rb") as f:
        corpus = pickle.load(f)
    assert len(df) == len(corpus)
    years = df["year"].values
    uniq_years = np.sort(np.unique(years))

    rows = []
    for k in range(4, 11):
        print(f"\nFitting k={k} ...")
        model = LdaModel(corpus=corpus, id2word=dictionary, num_topics=k,
                         random_state=RANDOM_SEED, passes=10, alpha="auto")
        dom = np.array([max(model.get_document_topics(b), key=lambda x: x[1])[0]
                        for b in corpus])
        stats_rows = []
        for t in range(k):
            share = pd.Series((dom == t).astype(float)).groupby(years).mean()
            slope, _, r, p, _ = stats.linregress(share.index.values, share.values)
            stats_rows.append({"topic": t, "slope": slope, "r2": r ** 2,
                               "bonf_p": min(p * k, 1.0), "n_docs": int((dom == t).sum())})
        st = pd.DataFrame(stats_rows)
        n_sig = int((st["bonf_p"] < 0.05).sum())
        for direction, sub in (("increasing", st[st["slope"] > 0]),
                               ("decreasing", st[st["slope"] < 0])):
            if sub.empty:
                continue
            best = sub.sort_values("r2", ascending=False).iloc[0]
            words = ", ".join(w for w, _ in model.show_topic(int(best["topic"]), topn=8))
            rows.append({"k": k, "direction": direction, "topic": int(best["topic"]),
                         "n_docs": int(best["n_docs"]), "slope_per_year": round(best["slope"], 4),
                         "r_squared": round(best["r2"], 3),
                         "bonferroni_p": round(best["bonf_p"], 5),
                         "n_topics_bonferroni_sig": n_sig, "top_words": words})
            print(rows[-1])

    out = pd.DataFrame(rows)
    out.to_csv(os.path.join(ARTIFACT_DIR, "k_sensitivity.csv"), index=False)
    pd.set_option("display.width", 250, "display.max_colwidth", 90)
    print("\n", out.to_string(index=False))


if __name__ == "__main__":
    main()
