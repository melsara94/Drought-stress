"""
STEP 7 -- Weighted / logistic trend checks and per-topic keyword percentages.

Answers reviewer concerns that (1) unweighted OLS on annual shares lets
years with 5-12 papers count as much as years with ~300, and (2) "mentions
per paper" is inflated by abstracts that repeat a family name.

Uses only corpus_with_topics.csv from step1 (no gensim needed).

USAGE (Spyder F5 or: python step7_weighted_checks.py):
Outputs in model_artifacts_k5:
   topic_trends_weighted.csv   -- OLS, WLS (weights = papers/year), logistic per topic
   pct_papers_per_topic.csv    -- % of papers mentioning each family/marker, by topic
   physio_by_topic.csv         -- which topics contain the physiological-marker papers
"""
import os, re
import numpy as np, pandas as pd
import statsmodels.api as sm
from scipy import stats

ARTIFACT_DIR = r"D:\Melina\Melina\mining_data\model_artifacts_k5"
RISING, DECLINING = 1, 4
df = pd.read_csv(os.path.join(ARTIFACT_DIR, "corpus_with_topics.csv"))
df["ft"] = df["title"].fillna("") + " " + df["abstract"].fillna("")
y = df["year"].values
T = np.sort(df["dominant_topic"].unique())

# ---- A. topic trends: OLS vs WLS vs logistic -------------------------------
rows = []
for t in T:
    f = (df["dominant_topic"].values == t).astype(float)
    s = pd.Series(f).groupby(y).agg(["mean", "size"])
    sl, _, r, p, _ = stats.linregress(s.index.values, s["mean"].values)
    w = sm.WLS(s["mean"].values, sm.add_constant(s.index.values - 2006.0), weights=s["size"].values).fit()
    lg = sm.GLM(f, sm.add_constant(y - 2006.0), family=sm.families.Binomial()).fit()
    rows.append(dict(topic=t, n=int(f.sum()), ols_slope=round(sl, 4), ols_p=p,
                     wls_slope=round(w.params[1], 4), wls_r2=round(w.rsquared, 3), wls_p=w.pvalues[1],
                     odds_ratio_per_year=round(float(np.exp(lg.params[1])), 3),
                     or_ci_low=round(float(np.exp(lg.conf_int()[1][0])), 3),
                     or_ci_high=round(float(np.exp(lg.conf_int()[1][1])), 3), logistic_p=lg.pvalues[1]))
o = pd.DataFrame(rows)
for c in ["ols_p", "wls_p", "logistic_p"]:
    o[c + "_bonf"] = (o[c] * len(o)).clip(upper=1).round(5)
    o[c] = o[c].round(5)
o.to_csv(os.path.join(ARTIFACT_DIR, "topic_trends_weighted.csv"), index=False)
print("\nA. Topic trends (Bonferroni over", len(o), "topics)\n", o.to_string(index=False))

# ---- B. % of papers mentioning each family, per topic ----------------------
def ci(w): return re.compile(w, re.I)
def cs(a): return re.compile(rf"(?<![A-Z]){a}(?![A-Z])")
FAM = {"WRKY": [ci("wrky")], "NAC": [cs("NAC")], "MYB": [ci("myb")], "bZIP": [ci("bzip")],
       "ERF": [cs("ERF")], "DREB": [ci("dreb")], "AP2": [cs("AP2")], "HSF": [ci("hsf")],
       "POD": [ci("peroxidase"), cs("POD")], "Proline": [ci("proline")],
       "SOD": [ci("superoxide dismutase"), cs("SOD")], "CAT": [ci("catalase"), cs("CAT")]}
has = lambda txt, pats: any(p.search(txt) for p in pats)
pct = {}
for name, pats in FAM.items():
    flag = np.array([has(t, pats) for t in df["ft"]])
    pct[name] = {f"topic_{t}": round(100 * flag[df["dominant_topic"].values == t].mean(), 1) for t in T}
pct = pd.DataFrame(pct).T
pct.to_csv(os.path.join(ARTIFACT_DIR, "pct_papers_per_topic.csv"))
print("\nB. % of papers mentioning each family, by topic\n", pct.to_string())

# ---- C. which topics carry the physiological-marker papers -----------------
PHYS = [ci("proline"), ci("catalase"), ci("peroxidase"), ci("superoxide dismutase"),
        ci("malondialdehyde"), ci("relative water content"), ci("electrolyte leakage"),
        cs("SOD"), cs("POD"), cs("CAT"), cs("MDA")]
flag = np.array([has(t, PHYS) for t in df["ft"]])
late = y >= 2022; early = y <= 2012
rows = []
for t in T:
    m = df["dominant_topic"].values == t
    rows.append(dict(topic=t, n=int(m.sum()), phys_papers=int(flag[m].sum()),
                     pct_of_topic=round(100 * flag[m].mean(), 1),
                     share_of_all_phys_papers=round(100 * flag[m].sum() / flag.sum(), 1),
                     pct_of_topic_2006_12=round(100 * flag[m & early].mean(), 1) if (m & early).sum() else np.nan,
                     pct_of_topic_2022_26=round(100 * flag[m & late].mean(), 1) if (m & late).sum() else np.nan))
c = pd.DataFrame(rows)
c.to_csv(os.path.join(ARTIFACT_DIR, "physio_by_topic.csv"), index=False)
print("\nC. Physiological-marker papers by topic\n", c.to_string(index=False))
print("\nDone.")
