"""
STEP 2 of 2 -- Regenerate Tables 1-4 and Figures 2/4/5/6/7 from the ONE
saved model produced by step1_fit_and_save_canonical_model.py.
==================================================================

This script does NOT re-read pubmed_raw.csv, does NOT re-clean text, and
does NOT re-fit LDA. It only loads what step1 already saved. That is the
whole point: Table 3's per-topic paper counts (n=94, n=382 or whatever
the real numbers turn out to be) are computed from the exact same
"dominant_topic" column used to draw Figure 4, so they are now
GUARANTEED to agree -- there is only one assignment of documents to
topics anywhere in the paper.

--------------------------------------------------------------------------
SETUP:
    pip install pandas gensim scipy matplotlib numpy statsmodels scikit-learn

USAGE:
    1. Run step1_fit_and_save_canonical_model.py first (once).
    2. Open model_artifacts/topic_top_words.csv, find your rising topic
       (AP2/ERF/DREB wording) and declining topic (breeding/yield
       wording), and set RISING_TOPIC_ID / DECLINING_TOPIC_ID below.
    3. Run: python step2_generate_tables_and_figures.py

    Produces, in D:\\Melina\\Melina\\mining_data\\model_artifacts:
       - table1_topic_structure.csv
       - table2_trend_significance.csv
       - table3_gene_family_frequency.csv
       - fig2_publication_counts.png
       - fig4_topic_share_annual.png
       - fig5_topic_share_binned.png
       - fig6_gene_family_comparison.png
--------------------------------------------------------------------------
"""

import os
import re

import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from scipy import stats

# =========================================================================
# CONFIG
# =========================================================================
DATA_DIR = r"D:\Melina\Melina\mining_data"
NUM_TOPICS = 5
ARTIFACT_DIR = os.path.join(DATA_DIR, f"model_artifacts_k{NUM_TOPICS}")
CORPUS_CSV = os.path.join(ARTIFACT_DIR, "corpus_with_topics.csv")  # the single source of truth

# >>> SET THESE after inspecting topic_top_words.csv from step1 <<<
RISING_TOPIC_ID = 1          # k=5: strongest increasing topic (gene_family, salt, family, proteins...)
DECLINING_TOPIC_ID = 4       # k=5: strongest decreasing topic (crops, breeding, review...)
# CHECK these against topic_top_words.csv in model_artifacts_k5 after step1.

# Matching rules (patterns are used WITHOUT a global ignore-case flag):
#  * distinctive names (WRKY, MYB, bZIP, DREB, HSF) and full words match
#    case-insensitively anywhere, so OsWRKY1 / TaMYB2 are counted;
#  * short ambiguous acronyms (ERF, AP2, NAC, SOD, POD, CAT) match
#    CASE-SENSITIVELY and only when not inside other capital letters, so
#    the common word "pod" (legume pods) or "cat" is not counted as POD/CAT.
GENE_FAMILY_KEYWORDS = {
    "DREB": r"(?i:dreb)",
    "AP2": r"(?<![A-Z])AP2(?![A-Z])",
    "ERF": r"(?<![A-Z])ERF(?![A-Z])",
    "WRKY": r"(?i:wrky)",
    "MYB": r"(?i:myb)",
    "bZIP": r"(?i:bzip)",
    "NAC": r"(?<![A-Z])NAC(?![A-Z])",
    "HSF": r"(?i:hsf)",
    "Proline": r"(?i:proline)",
    "SOD": r"(?i:superoxide dismutase)|(?<![A-Z])SOD(?![A-Z])",
    "POD": r"(?i:peroxidase)|(?<![A-Z])POD(?![A-Z])",
    "CAT": r"(?i:catalase)|(?<![A-Z])CAT(?![A-Z])",
}


def require_topic_ids():
    if RISING_TOPIC_ID is None or DECLINING_TOPIC_ID is None:
        raise SystemExit(
            "Set RISING_TOPIC_ID and DECLINING_TOPIC_ID at the top of this "
            "script first -- open model_artifacts/topic_top_words.csv and "
            "read off the correct topic numbers for THIS saved model."
        )


# =========================================================================
# Table 1 -- just re-export what step1 already computed (so it lives next
# to the other outputs)
# =========================================================================
def make_table1():
    src = os.path.join(ARTIFACT_DIR, "topic_top_words.csv")
    dst = os.path.join(ARTIFACT_DIR, "table1_topic_structure.csv")
    pd.read_csv(src).to_csv(dst, index=False)
    print(f"Saved {dst}")


# =========================================================================
# Table 2 + Figures 4/5 -- trend significance per topic, with correction
# =========================================================================
def bonferroni_correction(pvals):
    n = len(pvals)
    return [min(p * n, 1.0) for p in pvals]


def benjamini_hochberg_correction(pvals):
    n = len(pvals)
    order = np.argsort(pvals)
    ranked = np.array(pvals)[order]
    bh = ranked * n / (np.arange(n) + 1)
    # enforce monotonicity from the largest p-value down
    bh = np.minimum.accumulate(bh[::-1])[::-1]
    bh = np.clip(bh, 0, 1)
    out = np.empty(n)
    out[order] = bh
    return out.tolist()


def make_table2_and_annual_figures(df):
    pivot = pd.crosstab(df["year"], df["dominant_topic"])
    pivot_share = pivot.div(pivot.sum(axis=1), axis=0)
    years = pivot_share.index.values

    rows = []
    for topic_id in range(NUM_TOPICS):
        if topic_id not in pivot_share.columns:
            continue
        share = pivot_share[topic_id].values
        slope, intercept, r, p, se = stats.linregress(years, share)
        rows.append({
            "topic": topic_id, "slope_per_year": slope, "r_squared": r ** 2,
            "raw_p": p, "direction": "Increasing" if slope > 0 else "Decreasing",
        })

    table2 = pd.DataFrame(rows)
    table2["bonferroni_p"] = bonferroni_correction(table2["raw_p"].tolist())
    table2["fdr_bh_p"] = benjamini_hochberg_correction(table2["raw_p"].tolist())
    table2 = table2.sort_values("raw_p").reset_index(drop=True)

    out_csv = os.path.join(ARTIFACT_DIR, "table2_trend_significance.csv")
    table2.to_csv(out_csv, index=False)
    print(f"Saved {out_csv}")
    print(table2.round(4).to_string(index=False))

    # Figure 4: annual topic shares. Topics that survive Bonferroni are drawn
    # thick; the rest are thin so the significant trends stand out.
    strong = set(table2.loc[table2["bonferroni_p"] < 0.05, "topic"].tolist())
    plt.figure(figsize=(10, 6))
    for topic_id in pivot_share.columns:
        is_strong = topic_id in strong
        label = f"Topic {topic_id}" + (" (Bonferroni-significant)" if is_strong else "")
        plt.plot(years, pivot_share[topic_id].values, marker="o",
                 linewidth=2.8 if is_strong else 1.0,
                 markersize=5 if is_strong else 3,
                 alpha=1.0 if is_strong else 0.55, label=label)
    plt.xticks(range(int(years.min()), int(years.max()) + 1, 2))
    plt.xlabel("Year (2026 is a partial year)")
    plt.ylabel("Share of publications")
    plt.title("Annual share of publications assigned to each topic")
    plt.legend(fontsize=8)
    plt.tight_layout()
    fig4_path = os.path.join(ARTIFACT_DIR, "fig4_topic_share_annual.png")
    plt.savefig(fig4_path, dpi=150)
    plt.close()
    print(f"Saved {fig4_path}")

    # Figure 5: 3-year-binned topic shares, for readability
    # Bins are anchored to the FIRST analysed year (2006), so every bin is a
    # full 3-year window: 2006-08, 2009-11, ..., 2024-26.
    start = int(df["year"].min())
    df_binned = df.copy()
    df_binned["bin_idx"] = (df_binned["year"] - start) // 3
    pivot_bin = pd.crosstab(df_binned["bin_idx"], df_binned["dominant_topic"])
    pivot_bin_share = pivot_bin.div(pivot_bin.sum(axis=1), axis=0)
    bin_labels = [f"{start + 3 * i}-{str(start + 3 * i + 2)[-2:]}"
                  for i in pivot_bin_share.index]

    plt.figure(figsize=(10, 6))
    for topic_id in pivot_bin_share.columns:
        is_strong = topic_id in strong
        plt.plot(range(len(bin_labels)), pivot_bin_share[topic_id].values,
                 marker="o", linewidth=2.8 if is_strong else 1.0,
                 alpha=1.0 if is_strong else 0.55, label=f"Topic {topic_id}")
    plt.xticks(range(len(bin_labels)), bin_labels)
    plt.xlabel("Publication years (3-year bins; last bin includes partial 2026)")
    plt.ylabel("Share of publications")
    plt.title("Topic shares aggregated into 3-year bins")
    plt.legend(fontsize=8)
    plt.tight_layout()
    fig5_path = os.path.join(ARTIFACT_DIR, "fig5_topic_share_binned.png")
    plt.savefig(fig5_path, dpi=150)
    plt.close()
    print(f"Saved {fig5_path}")

    return table2


# =========================================================================
# Figure 2 -- raw annual publication counts (not shares)
# =========================================================================
def make_figure2(df):
    counts = df["year"].value_counts().sort_index()
    plt.figure(figsize=(10, 6))
    plt.bar(counts.index, counts.values, color="#2a6f4f")
    plt.xlabel("Year")
    plt.ylabel("Number of publications")
    plt.title("Annual number of publications retrieved for the query "
              "\"drought tolerance genes crops\"")
    plt.tight_layout()
    out_path = os.path.join(ARTIFACT_DIR, "fig2_publication_counts.png")
    plt.savefig(out_path, dpi=150)
    plt.close()
    print(f"Saved {out_path}")


# =========================================================================
# Table 3 + Figure 6 -- gene-family keyword frequency, using the SAME
# dominant_topic column as Figure 4, so n's are guaranteed to match
# =========================================================================
def make_table3_and_figure6(df):
    require_topic_ids()

    rising_df = df[df["dominant_topic"] == RISING_TOPIC_ID]
    declining_df = df[df["dominant_topic"] == DECLINING_TOPIC_ID]
    n_rising = len(rising_df)
    n_declining = len(declining_df)
    print(f"\nTopic {RISING_TOPIC_ID} (rising): n={n_rising} papers "
          f"(this MUST match the n in Figure 4's dominant_topic counts)")
    print(f"Topic {DECLINING_TOPIC_ID} (declining): n={n_declining} papers")

    def count_family(texts, pattern):
        regex = re.compile(pattern)   # case rules are inside each pattern
        return sum(len(regex.findall(str(t))) for t in texts)

    rising_text = (rising_df["title"].fillna("") + " " + rising_df["abstract"].fillna(""))
    declining_text = (declining_df["title"].fillna("") + " " + declining_df["abstract"].fillna(""))

    rows = []
    for family, pattern in GENE_FAMILY_KEYWORDS.items():
        r_count = count_family(rising_text, pattern)
        d_count = count_family(declining_text, pattern)
        rows.append({
            "gene_family": family,
            "topic_rising_mentions_per_paper": round(r_count / n_rising, 3) if n_rising else None,
            "topic_declining_mentions_per_paper": round(d_count / n_declining, 3) if n_declining else None,
        })

    table3 = pd.DataFrame(rows).sort_values(
        "topic_rising_mentions_per_paper", ascending=False
    ).reset_index(drop=True)

    out_csv = os.path.join(ARTIFACT_DIR, "table3_gene_family_frequency.csv")
    table3.to_csv(out_csv, index=False)
    print(f"Saved {out_csv}")
    print(table3.to_string(index=False))

    # Figure 6: grouped bar chart
    plt.figure(figsize=(9, 6))
    x = np.arange(len(table3))
    width = 0.35
    plt.bar(x - width / 2, table3["topic_rising_mentions_per_paper"].fillna(0),
            width, label=f"Topic {RISING_TOPIC_ID} (rising, n={n_rising})", color="#b0652f")
    plt.bar(x + width / 2, table3["topic_declining_mentions_per_paper"].fillna(0),
            width, label=f"Topic {DECLINING_TOPIC_ID} (declining, n={n_declining})", color="#2a6f4f")
    plt.xticks(x, table3["gene_family"], rotation=45, ha="right")
    plt.ylabel("Mentions per paper")
    plt.title("Gene/transcription-factor family mentions per paper")
    plt.legend()
    plt.tight_layout()
    fig6_path = os.path.join(ARTIFACT_DIR, "fig6_gene_family_comparison.png")
    plt.savefig(fig6_path, dpi=150)
    plt.close()
    print(f"Saved {fig6_path}")


# =========================================================================
# MAIN
# =========================================================================
def main():
    if not os.path.exists(CORPUS_CSV):
        raise SystemExit(
            f"{CORPUS_CSV} not found -- run step1_fit_and_save_canonical_model.py first."
        )
    df = pd.read_csv(CORPUS_CSV)
    print(f"Loaded canonical corpus: {len(df)} documents "
          f"(this is the ONLY dataframe used for every table/figure below)")

    make_table1()
    make_figure2(df)
    make_table2_and_annual_figures(df)
    make_table3_and_figure6(df)

    print("\n" + "=" * 70)
    print("All tables/figures regenerated from the single saved model.")
    print("Table 3's n's and Figure 4's topic sizes now come from the same")
    print("dominant_topic column, so they cannot disagree anymore.")
    print("=" * 70)


if __name__ == "__main__":
    main()
