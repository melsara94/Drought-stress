saved_model/  gensim LDA model (k=5, seed 42), dictionary, bigram phraser, corpus_with_topics.csv
              load with: LdaModel.load('saved_model/lda_model.gensim')  (gensim 4.3.3)
pubmed_raw.csv  the 2,000 retrieved PubMed records (PMID, title, abstract, year, journal)
pmids.txt       PMIDs only (abstracts can be re-fetched from PubMed with Entrez/Biopython)
Scripts: see PlantPhysiology_Supplementary_Files.zip -> code/
